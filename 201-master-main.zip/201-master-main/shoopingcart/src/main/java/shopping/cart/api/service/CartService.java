package shopping.cart.api.service;

import java.util.Map;
/**
 * @author 
 *
 */
public interface CartService {

	Map<String, Object> getAllProduct() throws Exception;

	

	

}
